<?php 
// Database connection
$conn = new mysqli('localhost', 'username', 'password', 'your_database_name');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate product_id to ensure it's a valid integer
if (isset($_POST['product_id']) && is_numeric($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']); // Convert to integer to prevent SQL injection

    // Prepared statement to delete the product
    $sql = "DELETE FROM products WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        // Bind the product_id to the prepared statement
        $stmt->bind_param("i", $product_id);

        // Execute the statement
        if ($stmt->execute()) {
            // Successful deletion
            $stmt->close();
            $conn->close();
            // Redirect to the admin dashboard after deletion
            header("Location: admin_dashboard.php?message=Product deleted successfully");
            exit;
        } else {
            // Error deleting the product
            echo "Error deleting product: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    } else {
        // Error preparing the statement
        echo "Error preparing query: " . $conn->error;
    }
} else {
    echo "Invalid product ID.";
}

// Close the connection
$conn->close();
?>
