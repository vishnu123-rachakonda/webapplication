<!DOCTYPE html>
<html lang="en">
<head>
    <title>Booking</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="book">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
    <link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
    <link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
    <link rel="stylesheet" type="text/css" href="plugins/jquery-ui-1.12.1.custom/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="styles/contact_styles.css">
    <link rel="stylesheet" type="text/css" href="styles/contact_responsive.css">
    <link rel="stylesheet" type="text/css" href="styles/main_styles.css">
</head>
<body>
    <style>
    /* General Styles */
    body {
        font-family: Arial, sans-serif;
        background-color: #f9f9f9;
        color: #333;
        margin: 0;
        padding: 0;
    }

    h2 {
        margin-bottom: 20px;
        font-size: 24px;
        font-weight: bold;
    }

    button {
        font-size: 16px;
        padding: 10px 20px;
        border-radius: 4px;
        border: none;
        cursor: pointer;
    }

    button.btn-primary {
        background-color: #007bff;
        color: #fff;
    }

    button.btn-primary:hover {
        background-color: #0056b3;
    }

    button.btn-success {
        background-color: #28a745;
        color: #fff;
    }

    button.btn-success:hover {
        background-color: #218838;
    }

    /* Cart Section Styles */
    .cart-items-container {
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 15px;
        margin-bottom: 20px;
        background-color: #f8f9fa;
    }

    .cart-item {
        align-items: center;
        justify-content: space-between;
    }

    .order-summary {
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 15px;
        background-color: #f8f9fa;
    }

    .order-summary h4 {
        font-size: 20px;
        margin-bottom: 10px;
    }

    .product-price, .total-price {
        font-size: 18px;
    }

    .total-price strong {
        color: #333;
    }

    /* Booking Section Styles */
    #booking1 {
        border: 1px solid #ddd;
        border-radius: 8px;
        background: #f8f9fa;
        padding: 20px;
    }

    form#bookingForm .form-group {
        margin-bottom: 15px;
    }

    form#bookingForm label {
        font-weight: bold;
    }

    form#bookingForm input,
    form#bookingForm textarea {
        width: 100%;
        padding: 10px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 4px;
        margin-top: 5px;
    }

    form#bookingForm textarea {
        resize: none;
    }

    form#bookingForm input:focus,
    form#bookingForm textarea:focus {
        border-color: #007bff;
        outline: none;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .cart-items-container, .order-summary, #booking1 {
            padding: 10px;
        }

        button {
            font-size: 14px;
            padding: 8px 16px;
        }

        h2 {
            font-size: 20px;
        }
    }
    </style>

    <div class="super_container">
        <!-- Header -->
        <header class="header trans_300">
            <div class="top_nav">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="top_nav_left">free shipping on all orders</div>
                        </div>
                        <div class="col-md-6 text-right">
                            <div class="top_nav_right">
                                <ul class="top_nav_menu">
                                    <li class="currency">
                                        <a href="#">usd <i class="fa fa-angle-down"></i></a>
                                        <ul class="currency_selection">
                                            <li><a href="#">cad</a></li>
                                            <li><a href="#">aud</a></li>
                                            <li><a href="#">eur</a></li>
                                            <li><a href="#">gbp</a></li>
                                        </ul>
                                    </li>
                                    <li class="language">
                                        <a href="#">English <i class="fa fa-angle-down"></i></a>
                                        <ul class="language_selection">
                                            <li><a href="#">French</a></li>
                                            <li><a href="#">Italian</a></li>
                                            <li><a href="#">German</a></li>
                                            <li><a href="#">Spanish</a></li>
                                        </ul>
                                    </li>
                                    <li class="account">
                                        <a href="#">My Account <i class="fa fa-angle-down"></i></a>
                                        <ul class="account_selection">
                                            <li><a href="logout.php"><i class="fa fa-sign-in" aria-hidden="true"></i>Sign In</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="main_nav_container">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 text-right">
                            <div class="logo_container">
                                <a href="#">Purple<span>Star</span></a>
                            </div>
                            <nav class="navbar">
                                <ul class="navbar_menu">
                                    <li><a href="index.php">home</a></li>
                                    <li><a href="categories.php">shop</a></li>
                                    <li><a href="#">pages</a></li>
                                    <li><a href="#">blog</a></li>
                                    <li><a href="contact.php">contact</a></li>
                                </ul>
                                <ul class="navbar_user">
                                    <li><a href="#"><i class="fa fa-search" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="fa fa-user" aria-hidden="true"></i></a></li>
                                    <li class="checkout">
                                        <a href="#">
                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                            <span id="checkout_items" class="checkout_items">0</span>
                                        </a>
                                    </li>
                                </ul>
                                <div class="hamburger_container">
                                    <i class="fa fa-bars" aria-hidden="true"></i>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <div class="fs_menu_overlay"></div>

        <div class="container contact_container">
            <div class="row">
                <div class="col">
                    <div class="breadcrumbs d-flex flex-row align-items-center">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li class="active"><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>Cart</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Cart Section -->
            <div class="row">
                <div class="col">
                    <div class="container mt-5">
                        <h2>Your Cart</h2>
                        <div class="row">
                            <!-- Cart Items - col-md-8 -->
                            <div class="col-md-8">
                                <div id="cart-items-container" class="cart-items-container">
                                    <!-- Dynamically generated cart items will be injected here -->
                                </div>
                            </div>

                            <!-- Order Summary - col-md-4 -->
                            <div class="col-md-4">
                                <div class="order-summary">
                                    <h4>Order Summary</h4>
                                    <p class="product-price">$20.00</p>
                                    <p class="total-price"><strong>Total: $59.98</strong></p>
                                    <!-- Razorpay Payment Button -->
                                    <button id="payment-button" class="btn btn-success">Pay Now</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Booking Section -->
            <div class="container mt-5">
                <h2>Booking</h2>
                <form id="bookingForm">
                    <div class="form-group">
                        <label for="userName">Name</label>
                        <input type="text" id="userName" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="userEmail">Email</label>
                        <input type="email" id="userEmail" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="userPhone">Phone</label>
                        <input type="text" id="userPhone" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="userAddress">Address</label>
                        <textarea id="userAddress" class="form-control" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Booking</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Razorpay Scripts -->
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
        var paymentHandler = function() {
            var options = {
                "key": "YOUR_RAZORPAY_KEY", // Replace with your Razorpay API key
                "amount": 5998, // Example amount (in paise)
                "currency": "INR",
                "name": "Your Company Name",
                "description": "Test Payment",
                "image": "https://yourcompanylogo.com/logo.png",
                "handler": function(response) {
                    alert("Payment successful! Razorpay Payment ID: " + response.razorpay_payment_id);
                },
                "prefill": {
                    "name": document.getElementById("userName").value,
                    "email": document.getElementById("userEmail").value,
                    "contact": document.getElementById("userPhone").value
                },
                "theme": {
                    "color": "#007bff"
                }
            };
            var rzp1 = new Razorpay(options);
            rzp1.open();
        };

        document.getElementById("payment-button").onclick = paymentHandler;
    </script>
</body>
</html>
