jQuery(document).ready(function ($) {
    "use strict";

    /* 

    1. Vars and Inits

    */

    const header = $('.header');
    const topNav = $('.top_nav');
    const hamburger = $('.hamburger_container');
    const menu = $('.hamburger_menu');
    let menuActive = false;
    const hamburgerClose = $('.hamburger_close');
    const fsOverlay = $('.fs_menu_overlay');

    setHeader();

    $(window).on('resize', function () {
        setHeader();
    });

    $(document).on('scroll', function () {
        setHeader();
    });

    initMenu();
    initThumbnail();
    initQuantity();
    initStarRating();
    initFavorite();
    initTabs();

    /* 

    2. Set Header

    */

    function setHeader() {
        if (window.innerWidth < 992) {
            header.css({'top': $(window).scrollTop() > 100 ? "0" : "0"});
        } else {
            header.css({'top': $(window).scrollTop() > 100 ? "-50px" : "0"});
        }
        if (window.innerWidth > 991 && menuActive) {
            closeMenu();
        }
    }

    /* 

    3. Init Menu

    */

    function initMenu() {
        if (hamburger.length) {
            hamburger.on('click', function () {
                if (!menuActive) {
                    openMenu();
                }
            });
        }

        if (fsOverlay.length) {
            fsOverlay.on('click', function () {
                if (menuActive) {
                    closeMenu();
                }
            });
        }

        if (hamburgerClose.length) {
            hamburgerClose.on('click', function () {
                if (menuActive) {
                    closeMenu();
                }
            });
        }

        if ($('.menu_item').length) {
            const items = $('.menu_item.has-children');
            items.each(function () {
                const item = $(this);
                item.on('click', function () {
                    $(this).toggleClass("active");
                    const panel = $(this).children().last();
                    panel.css('maxHeight', panel.css('maxHeight') ? null : `${panel[0].scrollHeight}px`);
                });
            });
        }
    }

    function openMenu() {
        menu.addClass('active');
        fsOverlay.css('pointer-events', "auto");
        menuActive = true;
    }

    function closeMenu() {
        menu.removeClass('active');
        fsOverlay.css('pointer-events', "none");
        menuActive = false;
    }

    /* 

    4. Init Thumbnail

    */

    function initThumbnail() {
        const thumbs = $('.single_product_thumbnails ul li');
        const singleImage = $('.single_product_image_background');

        thumbs.each(function () {
            const item = $(this);
            item.on('click', function () {
                thumbs.removeClass('active');
                item.addClass('active');
                const img = item.find('img').data('image');
                singleImage.css('background-image', `url(${img})`);
            });
        });
    }

    /* 

    5. Init Quantity

    */

    function initQuantity() {
        const plus = $('.plus');
        const minus = $('.minus');
        const value = $('#quantity_value');

        plus.on('click', function () {
            let x = parseInt(value.text(), 10);
            value.text(x + 1);
        });

        minus.on('click', function () {
            let x = parseInt(value.text(), 10);
            if (x > 1) {
                value.text(x - 1);
            }
        });
    }

    /* 

    6. Init Star Rating

    */

    function initStarRating() {
        const stars = $('.user_star_rating li');

        stars.each(function () {
            const star = $(this);

            star.on('click', function () {
                const i = star.index();

                stars.find('i').removeClass('fa-star').addClass('fa-star-o');
                for (let x = 0; x <= i; x++) {
                    $(stars[x]).find('i').removeClass('fa-star-o').addClass('fa-star');
                }
            });
        });
    }

    /* 

    7. Init Favorite

    */

    function initFavorite() {
        $(document).on('click', '.product_favorite', function () {
            $(this).toggleClass('active');
        });
    }

    /* 

    8. Init Tabs

    */

    function initTabs() {
        const tabs = $('.tabs li');
        const tabContainers = $('.tab_container');

        tabs.each(function () {
            const tab = $(this);
            const tabId = tab.data('active-tab');

            tab.on('click', function () {
                if (!tab.hasClass('active')) {
                    tabs.removeClass('active');
                    tabContainers.removeClass('active');
                    tab.addClass('active');
                    $('#' + tabId).addClass('active');
                }
            });
        });
    }
});
