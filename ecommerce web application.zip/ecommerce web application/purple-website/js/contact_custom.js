jQuery(document).ready(function ($) {
    "use strict";

    /* 
    1. Variables and Initialization
    */

    const header = $('.header');
    const topNav = $('.top_nav');
    const hamburger = $('.hamburger_container');
    const menu = $('.hamburger_menu');
    const hamburgerClose = $('.hamburger_close');
    const fsOverlay = $('.fs_menu_overlay');
    let menuActive = false;
    let map;

    setHeader();

    // Handle window resize
    $(window).on('resize', () => {
        setHeader();
    });

    // Handle scrolling
    $(document).on('scroll', () => {
        setHeader();
    });

    // Initialize menu and Google Maps
    initMenu();
    initGoogleMap();

    /* 
    2. Functions
    */

    // Set the header style based on scroll position
    function setHeader() {
        if (window.innerWidth < 992) {
            header.css({ top: "0" });
        } else {
            header.css({ top: $(window).scrollTop() > 100 ? "-50px" : "0" });
        }

        // Close menu for larger screens
        if (window.innerWidth > 991 && menuActive) {
            closeMenu();
        }
    }

    // Initialize hamburger menu functionality
    function initMenu() {
        if (hamburger.length) {
            hamburger.on('click', () => {
                if (!menuActive) {
                    openMenu();
                }
            });
        }

        if (fsOverlay.length) {
            fsOverlay.on('click', () => {
                if (menuActive) {
                    closeMenu();
                }
            });
        }

        if (hamburgerClose.length) {
            hamburgerClose.on('click', () => {
                if (menuActive) {
                    closeMenu();
                }
            });
        }

        // Handle menu items with submenus
        if ($('.menu_item').length) {
            $('.menu_item').each(function () {
                if ($(this).hasClass("has-children")) {
                    $(this).on('click', function () {
                        $(this).toggleClass("active");
                        const panel = $(this).children("ul")[0];
                        panel.style.maxHeight = panel.style.maxHeight ? null : panel.scrollHeight + "px";
                    });
                }
            });
        }
    }

    function openMenu() {
        menu.addClass('active');
        fsOverlay.css('pointer-events', "auto");
        menuActive = true;
    }

    function closeMenu() {
        menu.removeClass('active');
        fsOverlay.css('pointer-events', "none");
        menuActive = false;
    }

    // Initialize Google Maps
    function initGoogleMap() {
        const myLatlng = new google.maps.LatLng(42.373122, -71.112387);
        const mapOptions = {
            center: myLatlng,
            zoom: 16,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            draggable: true,
            scrollwheel: false,
            zoomControl: true,
            zoomControlOptions: {
                position: google.maps.ControlPosition.RIGHT_CENTER
            },
            mapTypeControl: false,
            scaleControl: false,
            streetViewControl: false,
            rotateControl: false,
            fullscreenControl: true,
            styles: [
                {
                    elementType: "geometry",
                    stylers: [{ color: "#f5f5f5" }]
                },
                {
                    elementType: "labels.text.fill",
                    stylers: [{ color: "#616161" }]
                },
                {
                    featureType: "poi",
                    elementType: "geometry",
                    stylers: [{ color: "#eeeeee" }]
                },
                {
                    featureType: "road",
                    elementType: "geometry",
                    stylers: [{ color: "#ffffff" }]
                },
                {
                    featureType: "water",
                    elementType: "geometry",
                    stylers: [{ color: "#c9c9c9" }]
                }
            ]
        };

        // Initialize the map
        map = new google.maps.Map(document.getElementById('map'), mapOptions);

        // Add a custom marker
        const markerImage = 'images/map_marker.png';
        new google.maps.Marker({
            position: myLatlng,
            map: map,
            icon: markerImage
        });

        // Re-center map after window resize
        google.maps.event.addDomListener(window, 'resize', () => {
            setTimeout(() => {
                google.maps.event.trigger(map, "resize");
                map.setCenter(myLatlng);
            }, 1400);
        });
    }
});
