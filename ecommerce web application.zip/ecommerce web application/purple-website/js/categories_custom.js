jQuery(document).ready(function ($) {
    "use strict";

    /* Vars and Inits */
    const header = $('.header');
    const menu = $('.hamburger_menu');
    const hamburger = $('.hamburger_container');
    const fsOverlay = $('.fs_menu_overlay');
    const hamburgerClose = $('.hamburger_close');
    let menuActive = false;
    let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];

    // Initialize all features
    setHeader();
    initMenu();
    initFavorite();
    initFixProductBorder();
    initIsotopeFiltering();
    initPriceSlider();
    initCheckboxes();
    updateCartPanel();

    $(window).on('resize', () => {
        setHeader();
        initFixProductBorder();
    });

    $(document).on('scroll', setHeader);

    /* Set Header */
    function setHeader() {
        const scrollTop = $(window).scrollTop();
        const isMobile = window.innerWidth < 992;

        header.css({ top: scrollTop > 100 && !isMobile ? "-50px" : "0" });

        if (window.innerWidth > 991 && menuActive) {
            closeMenu();
        }
    }

    /* Initialize Menu */
    function initMenu() {
        if (hamburger.length) {
            hamburger.on('click', openMenu);
        }

        if (fsOverlay.length) {
            fsOverlay.on('click', closeMenu);
        }

        if (hamburgerClose.length) {
            hamburgerClose.on('click', closeMenu);
        }

        $('.menu_item.has-children').on('click', function () {
            $(this).toggleClass("active");
            const panel = $(this).children("ul");
            panel.css('maxHeight', panel.css('maxHeight') ? null : panel[0].scrollHeight + "px");
        });
    }

    function openMenu() {
        menu.addClass('active');
        fsOverlay.css('pointer-events', "auto");
        menuActive = true;
    }

    function closeMenu() {
        menu.removeClass('active');
        fsOverlay.css('pointer-events', "none");
        menuActive = false;
    }

    /* Initialize Favorite */
    function initFavorite() {
        $('.favorite').each(function () {
            $(this).on('click', function () {
                $(this).toggleClass('active');
            });
        });
    }

    /* Fix Product Border */
    function initFixProductBorder() {
        const products = $('.product_filter:visible');
        const width = window.innerWidth;

        products.css('border-right', 'solid 1px #e9e9e9');
        const conditions = [
            { maxWidth: 480, step: 1 },
            { maxWidth: 576, step: 2 },
            { maxWidth: 768, step: 3 },
            { maxWidth: 992, step: 3 },
            { maxWidth: Infinity, step: 4 }
        ];

        const condition = conditions.find(c => width <= c.maxWidth);

        products.each((index, product) => {
            if ((index + 1) % condition.step === 0) {
                $(product).css('border-right', 'none');
            }
        });
    }

    /* Isotope Filtering */
    function initIsotopeFiltering() {
        const grid = $('.product-grid');

        if (grid.length) {
            grid.isotope({
                itemSelector: '.product-item',
                getSortData: {
                    price: item => parseFloat($(item).find('.product_price').text().replace('$', '')),
                    name: '.product_name'
                },
                animationOptions: {
                    duration: 750,
                    easing: 'linear',
                    queue: false
                }
            });

            $('.type_sorting_btn').on('click', function () {
                const option = JSON.parse($(this).attr('data-isotope-option'));
                grid.isotope(option);
            });

            $('.num_sorting_btn').on('click', function () {
                const numFilter = ':nth-child(-n+' + $(this).text() + ')';
                grid.isotope({ filter: numFilter });
            });

            $('.filter_button').on('click', function () {
                const priceRange = $('#amount').val().split('-').map(p => parseFloat(p.replace('$', '').trim()));
                grid.isotope({
                    filter: function () {
                        const itemPrice = parseFloat($(this).find('.product_price').text().replace('$', ''));
                        return itemPrice >= priceRange[0] && itemPrice <= priceRange[1];
                    }
                });
            });
        }
    }

    /* Price Slider */
    function initPriceSlider() {
        $("#slider-range").slider({
            range: true,
            min: 0,
            max: 1000,
            values: [0, 580],
            slide: (event, ui) => {
                $("#amount").val(`$${ui.values[0]} - $${ui.values[1]}`);
            }
        });
        $("#amount").val(`$${$("#slider-range").slider("values", 0)} - $${$("#slider-range").slider("values", 1)}`);
    }

    /* Checkboxes */
    function initCheckboxes() {
        $('.checkboxes li').on('click', function () {
            $(this).toggleClass('active');
            const icon = $(this).find('i');
            icon.toggleClass('fa-square fa-square-o');
        });

        $('.show_more').on('click', function () {
            $('.checkboxes').toggleClass('active');
        });
    }

    /* Cart Functions */
    function addToCart(itemName, price) {
        cartItems.push({ name: itemName, price });
        localStorage.setItem("cartItems", JSON.stringify(cartItems));
        updateCart();
        updateCartPanel();
    }

    function removeItemFromCart(itemName) {
        cartItems = cartItems.filter(item => item.name !== itemName);
        localStorage.setItem("cartItems", JSON.stringify(cartItems));
        updateCart();
        updateCartPanel();
    }

    function updateCart() {
        $('#checkout_items').text(cartItems.length);
    }

    function updateCartPanel() {
        const cartItemsContainer = $('#cart-items-container').empty();
        cartItems.forEach(item => {
            const cartItem = $(`
                <div class="cart-item">
                    <div class="cart-item-content">
                        <img src="${item.image || 'images/fallback.png'}" 
                             alt="${item.name}" class="cart-item-image" 
                             onerror="this.src='images/fallback.png';">
                        <div class="cart-item-details">
                            <h4>${item.name}</h4>
                            <p class="product-price">$${item.price.toFixed(2)}</p>
                            <button class="remove-item">Remove</button>
                        </div>
                    </div>
                </div>
            `);
            cartItem.find('.remove-item').on('click', () => removeItemFromCart(item.name));
            cartItemsContainer.append(cartItem);
        });
    }

    function loadCartItems() {
        cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
        updateCartPanel();
    }

    loadCartItems();
});
