jQuery(document).ready(function ($) {
    "use strict";

    /* 

    1. Vars and Inits

    */

    const header = $('.header');
    const topNav = $('.top_nav');
    const mainSlider = $('.main_slider');
    const hamburger = $('.hamburger_container');
    const menu = $('.hamburger_menu');
    let menuActive = false;
    const hamburgerClose = $('.hamburger_close');
    const fsOverlay = $('.fs_menu_overlay');

    setHeader();

    $(window).on('resize', function () {
        initFixProductBorder();
        setHeader();
    });

    $(document).on('scroll', function () {
        setHeader();
    });

    initMenu();
    initTimer();
    initFavorite();
    initFixProductBorder();
    initIsotopeFiltering();
    initSlider();

    /* 

    2. Set Header

    */

    function setHeader() {
        if (window.innerWidth < 992) {
            header.css({ top: "0" });
        } else {
            if ($(window).scrollTop() > 100) {
                header.css({ top: "-50px" });
            } else {
                header.css({ top: "0" });
            }
        }

        if (window.innerWidth > 991 && menuActive) {
            closeMenu();
        }
    }

    /* 

    3. Init Menu

    */

    function initMenu() {
        if (hamburger.length) {
            hamburger.on('click', function () {
                if (!menuActive) {
                    openMenu();
                }
            });
        }

        if (fsOverlay.length) {
            fsOverlay.on('click', function () {
                if (menuActive) {
                    closeMenu();
                }
            });
        }

        if (hamburgerClose.length) {
            hamburgerClose.on('click', function () {
                if (menuActive) {
                    closeMenu();
                }
            });
        }

        if ($('.menu_item').length) {
            const items = document.getElementsByClassName('menu_item');

            for (let i = 0; i < items.length; i++) {
                if (items[i].classList.contains("has-children")) {
                    items[i].onclick = function () {
                        this.classList.toggle("active");
                        const panel = this.children[1];
                        if (panel.style.maxHeight) {
                            panel.style.maxHeight = null;
                        } else {
                            panel.style.maxHeight = `${panel.scrollHeight}px`;
                        }
                    };
                }
            }
        }
    }

    function openMenu() {
        menu.addClass('active');
        fsOverlay.css('pointer-events', "auto");
        menuActive = true;
    }

    function closeMenu() {
        menu.removeClass('active');
        fsOverlay.css('pointer-events', "none");
        menuActive = false;
    }

    /* 

    4. Init Timer

    */

    function initTimer() {
        if ($('.timer').length) {
            const date = new Date();
            date.setDate(date.getDate() + 3); // Set target date 3 days from now
            const targetDate = date.getTime();

            const d = $('#day');
            const h = $('#hour');
            const m = $('#minute');
            const s = $('#second');

            setInterval(function () {
                const currentDate = new Date().getTime();
                let secondsLeft = (targetDate - currentDate) / 1000;

                const days = parseInt(secondsLeft / 86400);
                secondsLeft %= 86400;

                const hours = parseInt(secondsLeft / 3600);
                secondsLeft %= 3600;

                const minutes = parseInt(secondsLeft / 60);
                const seconds = parseInt(secondsLeft % 60);

                d.text(days);
                h.text(hours);
                m.text(minutes);
                s.text(seconds);
            }, 1000);
        }
    }

    /* 

    5. Init Favorite

    */

    function initFavorite() {
        const favs = $('.favorite');

        favs.each(function () {
            const fav = $(this);
            let active = fav.hasClass('active');

            fav.on('click', function () {
                active = !active;
                fav.toggleClass('active', active);
            });
        });
    }

    /* 

    6. Init Fix Product Border

    */

    function initFixProductBorder() {
        if ($('.product_filter').length) {
            const products = $('.product_filter:visible');
            const wdth = window.innerWidth;

            products.css('border-right', 'solid 1px #e9e9e9');

            if (wdth < 480) {
                products.css('border-right', 'none');
            } else if (wdth < 576) {
                products.each((i, product) => {
                    if (i % 2 !== 0) $(product).css('border-right', 'none');
                });
            } else if (wdth < 768) {
                products.each((i, product) => {
                    if (i % 3 === 2) $(product).css('border-right', 'none');
                });
            } else if (wdth < 992) {
                products.each((i, product) => {
                    if (i % 4 === 3) $(product).css('border-right', 'none');
                });
            } else {
                products.each((i, product) => {
                    if (i % 5 === 4) $(product).css('border-right', 'none');
                });
            }
        }
    }

    /* 

    7. Init Isotope Filtering

    */

    function initIsotopeFiltering() {
        const buttons = $('.grid_sorting_button');
        if (buttons.length) {
            buttons.click(function () {
                setTimeout(initFixProductBorder, 500);

                buttons.removeClass('active');
                $(this).addClass('active');

                const selector = $(this).attr('data-filter');
                $('.product-grid').isotope({
                    filter: selector,
                    animationOptions: {
                        duration: 750,
                        easing: 'linear',
                        queue: false
                    }
                });

                return false;
            });
        }
    }

    /* 

    8. Init Slider

    */

    function initSlider() {
        if ($('.product_slider').length) {
            const slider = $('.product_slider');

            slider.owlCarousel({
                loop: false,
                dots: false,
                nav: false,
                responsive: {
                    0: { items: 1 },
                    480: { items: 2 },
                    768: { items: 3 },
                    991: { items: 4 },
                    1280: { items: 5 },
                    1440: { items: 5 }
                }
            });

            $('.product_slider_nav_left').on('click', () => slider.trigger('prev.owl.carousel'));
            $('.product_slider_nav_right').on('click', () => slider.trigger('next.owl.carousel'));
        }
    }
});
