<?php

// Database configuration
$hostName = "localhost";
$dbUser = "root";
$dbPassword = ""; // Empty in local development environments like XAMPP
$dbName = "login_register";

// Create a secure connection using mysqli with improved error handling
$conn = mysqli_connect($hostName, $dbUser, $dbPassword, $dbName);

// Check the connection and handle errors properly
if (!$conn) {
    // Log the error to a file for debugging (in production, disable error messages)
    error_log("Connection failed: " . mysqli_connect_error());
    
    // Display a user-friendly message (but not the actual error for security reasons)
    die("Unable to connect to the database at the moment. Please try again later.");
}

?>
