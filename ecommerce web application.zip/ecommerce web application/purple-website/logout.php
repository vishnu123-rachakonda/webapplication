<?php
session_start();

// Check if the user is an admin or a regular user before destroying the session
if (isset($_SESSION['admin'])) {
    // If the user is an admin, redirect to index.php
    session_unset();  // Clear all session variables
    session_destroy();  // Destroy the session
    header("Location: index.php?message=logged_out");
    exit();
} elseif (isset($_SESSION['user'])) {
    // If the user is a regular user, redirect to login.php
    session_unset();  // Clear all session variables
    session_destroy();  // Destroy the session
    header("Location: login.php?message=logged_out");
    exit();
} else {
    // If no session found, redirect to login.php (default case)
    session_unset();  // Clear all session variables
    session_destroy();  // Destroy the session
    header("Location: login.php?message=logged_out");
    exit();
}
?>
