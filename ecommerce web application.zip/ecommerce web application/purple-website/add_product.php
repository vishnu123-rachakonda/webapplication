<?php
// Database connection
$conn = new mysqli('localhost', 'username', 'password', 'your_database_name');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Form data
$product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
$product_price = mysqli_real_escape_string($conn, $_POST['product_price']);
$product_image = $_FILES['product_image']['name'];

// Directory to save the uploaded image
$target_dir = "uploads/";
$target_file = $target_dir . basename($product_image);

// Image file validation (Optional: only allow certain types of images)
$image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$allowed_file_types = ['jpg', 'jpeg', 'png', 'gif'];

// Check if the image is valid
if (!in_array($image_file_type, $allowed_file_types)) {
    die("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");
}

// Check if the file already exists
if (file_exists($target_file)) {
    die("Sorry, the file already exists.");
}

// Check for errors in the uploaded file
if ($_FILES['product_image']['error'] !== UPLOAD_ERR_OK) {
    die("Error uploading image. Error code: " . $_FILES['product_image']['error']);
}

// Upload image and insert product data into the database
if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file)) {
    // Prepare the SQL query
    $sql = "INSERT INTO products (name, price, image) VALUES ('$product_name', '$product_price', '$product_image')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Product added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Error uploading image.";
}

$conn->close();

// Redirect to admin dashboard
header("Location: admin_dashboard.php");
exit;
?>
